export { ChordModule } from './ChordModule'
