export { ScaleModule } from './ScaleModule'
